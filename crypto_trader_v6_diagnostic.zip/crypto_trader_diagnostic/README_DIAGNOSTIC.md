# crypto_trader v6.0 — DIAGNOSTIC BUILD

## Purpose
Validate live order open → manage → close end-to-end before committing
to a full production deployment on a new EC2 instance.

## Key differences from production:
- `RISK_PER_TRADE_USD = 1.00` — minimum $1 risk per trade
- `PAPER_TRADING = True` by default — set to False only after validation
- No circuit breaker — bot keeps trading regardless of losses
- Relaxed entry gates — lower grade threshold, VWAP disabled
- Ultra-tight stops (0.1x ATR) — positions close within a few ticks
- All strategies active — gathers data across BTC/ETH/SOL patterns

## Deploy steps:
1. SCP this folder to a fresh EC2 instance
2. Run `bash setup_ec2.sh` and enter credentials
3. Watch `python status.py` — confirm trades open and close cleanly
4. Check `python diagnostic_report.py` for validation summary
5. Once validated, deploy the production tarball to a new instance

## DO NOT use for live trading at scale — $1 risk only.
